// config/contracts.js
import marketAbi from './market.abi.json'
import vaultAbi  from './vault.abi.json'

export const MARKETS = [
    { id: 'market1', label: 'Market 1', address: '0x5a0EaDD1a503821d841D21B68d903fE7301d8576', abi: marketAbi },
    { id: 'market2', label: 'Market 2', address: '0x7D058378142d8507B9c3b57c50359037e84EFbb8', abi: marketAbi },
    { id: 'market3', label: 'Market 3', address: '0xE180915F2Dd64caD52FC1e0428EeD7f695B785c5', abi: marketAbi },
]

export const VAULTS = [
    { id: 'vault1', label: 'Vault 1', address: '0xA7B7C031243d20E9D4057428Cf171d77F60A5B0B', abi: vaultAbi },
    { id: 'vault2', label: 'Vault 2', address: '0x5392b9556983e3B1a0D6D20C34Cb0037aC15baB6', abi: vaultAbi },
]