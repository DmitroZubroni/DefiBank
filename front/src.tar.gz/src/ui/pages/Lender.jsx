import { useContext, useState } from 'react';
import { Button, Form, FormControl, FormGroup, FormLabel, Card, ButtonGroup } from 'react-bootstrap';
import { AtlantContext } from '../../core/context';
import { ContractService } from '../../service/ContractService';
import { VAULTS } from '../../service/contracts.js';
import Header from "../component/Header.jsx";

const vaultServices = VAULTS.map(v => ({ ...v, service: new ContractService(v.abi, v.address) }));

const ACTIONS = ['deposit', 'withdraw'];

const VaultForm = ({ label, service }) => {
    const { wallet } = useContext(AtlantContext);
    const [amount, setAmount] = useState('');

    const handle = async (action) => {
        try {
            await service[action](amount, wallet);
            alert('success');
        } catch {
            alert('error');
        }
    };

    return (
        <div>

            <Card className="mb-3">
                <Card.Header>{label}</Card.Header>
                <Card.Body>
                    <FormGroup>
                        <FormLabel>Amount</FormLabel>
                        <FormControl
                            type="number" placeholder="1" min="0"
                            value={amount} onChange={e => setAmount(e.target.value)}
                        />
                    </FormGroup>
                    <ButtonGroup className="mt-2">
                        {ACTIONS.map(a => (
                            <Button key={a} variant="outline-primary" disabled={!amount} onClick={() => handle(a)}>
                                {a.charAt(0).toUpperCase() + a.slice(1)}
                            </Button>
                        ))}
                    </ButtonGroup>
                </Card.Body>
            </Card>
        </div>

    );
};

const Lender = () => (
    <div className="p-3">
        <Header/>
        <h4>Vaults</h4>
        {vaultServices.map(v => <VaultForm key={v.id} {...v} />)}
    </div>
);

export default Lender;